import React, { Component, useEffect } from 'react';
import { Text, View, TextInput, StyleSheet, Button, TouchableOpacity, Image, ScrollView, ImageBackground } from 'react-native';

const BookingPage = (props) => {

    const gotoBooking = () => {
        props.navigation.navigate("Booking");
    }
    return (

        <View style={{ flex: 1, marginTop: 30 }}>

            {/* Lake Booking */}
            <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity onPress={gotoBooking}>
                    <Image source={require('./arrow.png')} style={{ height: 20, width: 24, marginTop: 25, marginLeft: 10 }} />
                </TouchableOpacity>
                <Text style={styles.txt}>LAKE BOOKING</Text>
            </View>

            {/* Lake Availability */}
            <View>
                <Text style={styles.rule}>Lake avalibility</Text>
                <Image source={require('./Calendar.png')} style={{ width: "90%", height: 350, marginLeft: 10, marginTop: 10 }} />


            </View>

            {/* Number Of Anglers */}
            <View style={{ flexDirection: 'row' }}>
                <Text style={styles.txt1}>Number for anglers</Text>
                <TextInput placeholder='3' style={styles.input} placeholderTextColor={'white'} />

            </View>
            {/* Total and PayNow Button */}
            <View style={{ flexDirection: 'row', backgroundColor: '#101010', paddingBottom: 20, borderRadius: 20, position: 'absolute', bottom: 0, width: "100%" }}>
                <Text style={styles.price1}>Total :<Text style={styles.price}> $600.00</Text></Text>
                <TouchableOpacity style={styles.btn} >
                    <Text style={styles.btntxt} >Pay Now!</Text>
                </TouchableOpacity>

            </View>

        </View>
    )
}
const styles = StyleSheet.create({
    txt: {
        fontSize: 25,
        fontFamily: 'audiowide_regular',
        color: '#999999',
        fontWeight: 400,
        paddingLeft: 60,
        marginTop: 20
    },
    txt1: {
        fontSize: 20,
        fontFamily: 'audiowide_regular',
        color: '#999999',
        fontWeight: 500,
        paddingLeft: 20,
        marginTop: 65,
        width: 250,
        height: 43,
        textAlign: 'center',
        marginLeft: 10

    },
    input: {
        backgroundColor: '#101010',
        opacity: 0.9,
        borderTopRightRadius: 12,
        borderBottomRightRadius: 12,
        color: 'white',
        fontSize: 18,
        width: 90,
        height: 43,
        fontFamily: 'sf_pro',
        marginTop: 60,
        textAlign: 'center',


    },
    price: {
        fontSize: 25,
        fontFamily: 'sf-pro',
        color: '#ffffff',
        fontWeight: 400,
        paddingLeft: 60,
        marginTop: 20

    },
    price1: {
        fontSize: 20,
        fontFamily: 'sf-pro',
        color: '#ffffff',
        fontWeight: 500,
        paddingLeft: 20,
        marginTop: 30
    },
    btn: {
        elevation: 9,
        backgroundColor: '#4DED75',
        paddingVertical: 10,
        paddingHorizontal: 12,
        marginTop: 25,
        marginLeft: 40,
        borderRadius: 10



    },
    btntxt: {
        color: 'black',
        fontSize: 18,
        fontWeight: 500,
        alignSelf: 'center',
        fontFamily: 'audiowide_regular',
        textTransform: 'uppercase',

    },

})
export default BookingPage;